# LCD_I2C
Arduino library to control a 16x2 LCD via an I2C adapter based on PCF8574
